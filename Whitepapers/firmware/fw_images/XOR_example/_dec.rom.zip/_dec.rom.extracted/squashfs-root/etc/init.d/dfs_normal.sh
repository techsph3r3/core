#!/bin/sh
radartool usenol 1
radartool dfsdebug 0
